from django.apps import AppConfig


class PyagentAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pyagent_app'
